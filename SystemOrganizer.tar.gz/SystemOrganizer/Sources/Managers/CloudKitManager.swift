import Foundation
import CloudKit

class CloudKitManager: NSObject, ObservableObject {
    @Published var isCloudKitAvailable = false
    @Published var syncStatus = "Initializing..."
    @Published var lastSyncDate: Date?
    
    private let container = CKContainer.default()
    private let database: CKDatabase
    private var syncTimer: Timer?
    
    override init() {
        self.database = container.privateCloudDatabase
        super.init()
    }
    
    func initializeCloudKit() {
        container.accountStatus { [weak self] status, error in
            DispatchQueue.main.async {
                switch status {
                case .available:
                    self?.isCloudKitAvailable = true
                    self?.syncStatus = "CloudKit Ready"
                    self?.setupAutoSync()
                case .noAccount:
                    self?.syncStatus = "No iCloud Account"
                case .restricted:
                    self?.syncStatus = "CloudKit Restricted"
                case .couldNotDetermine:
                    self?.syncStatus = "Could not determine CloudKit status"
                @unknown default:
                    self?.syncStatus = "Unknown CloudKit status"
                }
            }
        }
    }
    
    private func setupAutoSync() {
        syncTimer = Timer.scheduledTimer(withTimeInterval: 300, repeats: true) { [weak self] _ in
            self?.syncData()
        }
    }
    
    func syncData() {
        guard isCloudKitAvailable else { return }
        
        let query = CKQuery(recordType: "Automation", predicate: NSPredicate(value: true))
        
        database.perform(query, inZoneWith: nil) { [weak self] records, error in
            DispatchQueue.main.async {
                if let error = error {
                    self?.syncStatus = "Sync failed: \(error.localizedDescription)"
                } else {
                    self?.syncStatus = "Synced at \(Date().formatted())"
                    self?.lastSyncDate = Date()
                }
            }
        }
    }
    
    func saveAutomation(_ automation: AutomationModel) {
        guard isCloudKitAvailable else { return }
        
        let record = CKRecord(recordType: "Automation")
        record["name"] = automation.name
        record["description"] = automation.description
        record["isEnabled"] = automation.isEnabled
        record["scriptPath"] = automation.scriptPath
        record["schedule"] = automation.schedule
        record["lastRun"] = automation.lastRun
        
        database.save(record) { [weak self] _, error in
            DispatchQueue.main.async {
                if let error = error {
                    self?.syncStatus = "Save failed: \(error.localizedDescription)"
                } else {
                    self?.syncStatus = "Automation saved to CloudKit"
                }
            }
        }
    }
    
    func fetchAutomations(completion: @escaping ([AutomationModel]) -> Void) {
        guard isCloudKitAvailable else {
            completion([])
            return
        }
        
        let query = CKQuery(recordType: "Automation", predicate: NSPredicate(value: true))
        
        database.perform(query, inZoneWith: nil) { records, error in
            var automations: [AutomationModel] = []
            
            if let records = records {
                automations = records.compactMap { record in
                    AutomationModel(
                        id: record.recordID.recordName,
                        name: record["name"] as? String ?? "",
                        description: record["description"] as? String ?? "",
                        isEnabled: record["isEnabled"] as? Bool ?? false,
                        scriptPath: record["scriptPath"] as? String ?? "",
                        schedule: record["schedule"] as? String ?? "",
                        lastRun: record["lastRun"] as? Date
                    )
                }
            }
            
            DispatchQueue.main.async {
                completion(automations)
            }
        }
    }
    
    deinit {
        syncTimer?.invalidate()
    }
}
